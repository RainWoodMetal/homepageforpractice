<template>
  <div style="background-color:#f3f3f3">
      <!-- {{functions}} -->
      <loop-image></loop-image>
      <function-menu :functions="functions">
          <news-list></news-list>
      </function-menu>
      <mould v-for="(m, index) in homelist" :key="index" :mouldData="m">
          <div v-if="containerSelect(m.section) !='fof'">
              <mould-content v-for="(item, index) in m.contents" :key="index" :itemData="item" :layout="layout(m.section)" :section="m.section" :itemIndex="index"></mould-content>
          </div>
          <fof-content v-else-if="containerSelect(m.section) =='fof'" :itemsCount="m.contents.length">
              <mould-content v-for="(item, index) in m.contents" :key="index" :itemData="item" :layout="layout(m.section)" :section="m.section" :itemIndex="index"></mould-content>
          </fof-content>
      </mould>
      
  </div>
</template>

<script>
import loopImage from '../components/Loop-Img'
import Mould from '../components/Mould'
import MouldContent from '../components/Mould-Content'
import FofContent from '../components/FOF-Content'
import FunctionMenu from './Function-Menu'
import NewsList from './News-List'

export default {
    name:'maincontainer',
    components:{
        loopImage,
        Mould,
        MouldContent,
        FofContent,
        FunctionMenu,
        NewsList
    },
    data(){
        return{
            homelist: this.$store.state.homedata.homelist,
            functions: this.$store.state.homedata.functions,
        }
    },
    methods:{
        layout: function(section){
            var result;
            if(section=="reading"){
                result = "layout1"
            }
            else if(section=="research"){
                result = "layout2"
            }
            else if(section=="selected"){
                result = "layout3"
            }
            else if(section=="video"){
                result = "layout4"
            }
            else if(section=="FOF"){
                result = "layout5"
            }
            else if(section=="product"){
                result = "layout6"
            }

            return result;
        },
        isFof(section){
            var result = false;
            if (section=="FOF") {
                result = true
            }
            return result;
        },
        containerSelect(section){
            var result = "col";
            if(this.isFof(section))
            {
                result = "fof";
            }
            else if(section=="study")
            {
                result = "";
            }
            return result;
        }
    },
}
</script>

<style scoped>
.clearBoth::after, .clearBoth::before{
  content: "";
  display: table;
  clear: both;
}
</style>