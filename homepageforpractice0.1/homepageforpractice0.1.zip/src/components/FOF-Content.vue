<template>
  <scroller :lock-y=true>
      <div ref="container" class="fof-container clearBoth" :style="{width: 'calc((6.55rem + 36px) * '+ itemsCount +')'}">
          <!-- <content-mould3 style="float:left; margin-right:12px" v-for="item in fofData" :key="item.index" :type="item.type" :name="item.name" :persentNumber="item.persentNumber" :remark="item.remark">
          </content-mould3> -->
          <slot></slot>
      </div>
  </scroller>
</template>

<script>
import { Scroller } from 'vux'
// import ContentMould3 from '../components/Content-Mould3'

export default {
    name:'fof-content',
    components: {
        Scroller,
        // ContentMould3,
    },
    props:{
        itemsCount: Number,
    },
    
}
</script>

<style>
.fof-container{
    padding:12px 12px 22px;
    /* width:calc((6.55rem + 36px) * 3) */
}
.clearBoth::after, .clearBoth::before{
    content: "";
    display: table;
    clear: both;
}
</style>