// 列布局
<template>
  <div class="testtesttest">
      <div v-for="(item, index) in items" :key="index">
        <slot :name="'mould' + index"></slot>
      </div>
  </div>
</template>

<script>
export default {
    name: 'columnLayout1',
    props: {
        item: Object,
    }
}
</script>

<style>

</style>