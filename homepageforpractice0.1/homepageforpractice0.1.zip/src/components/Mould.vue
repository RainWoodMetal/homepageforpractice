<template>
  <div class="column clearBoth">
      <mould-header class="" v-if="mouldData.topic" :topic="mouldData.topic" :sub-topic="mouldData.sub_topic"></mould-header>
      <slot></slot>
  </div>
</template>

<script>
import MouldHeader from '../components/Mould-Header'

export default {
    name: 'mould',
    components:{
      MouldHeader,
    },
    props:{
      mouldData: Object,
    }
}
</script>

<style scoped>
.column{
  margin-bottom: .4rem;
  background-color: #fff;
  position: relative;
}
.clearBoth::after, .clearBoth::before{
  content: "";
  display: table;
  clear: both;
}
</style>