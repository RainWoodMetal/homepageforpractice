<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
#app{
    max-width: 640px;
    overflow-x: hidden;
    margin: auto;
    background-color: white;
    background-repeat:no-repeat;
}
h1,h2,h3,h4,h5,h6{
    font-size: 100%;
    font-weight: 400;
}
html{
  /* 0.04 * vw */
  font-size: 25.6px;
}
a{
  text-decoration: none;
}
body{
  background-color: #f3f3f3;
  font-size: 14px;
}
img{
  height: 100%;
  width: 100%;
}
</style>
