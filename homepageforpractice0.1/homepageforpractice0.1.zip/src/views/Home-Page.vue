<template>
  <div>
    <main-header class="header"></main-header>
    <main-container class="container"></main-container>
    <!-- <main-menu class="menu"></main-menu> -->
  </div>
</template>

<script>
import MainHeader from '../components/Main-Header'
import MainContainer from '../components/Main-Container'
// import MainMenu from '../components/Main-Menu'

export default {
    name: 'homepage',
    components: {
      MainHeader,
      MainContainer,
      // MainMenu,
    },
    mounted(){
      this.getData();
    },
    methods:{
      getData(){
        this.addDataToStore();
      },
      addDataToStore(){
        var state = require('../assets/json/state.json');
        if(state.msg=='成功')
        {
          this.$store.commit('addHomeData', state.result);
        }
      },
    }
}
</script>

<style>
*{
    margin: 0px;
    padding: 0px;
    border: 0;
    z-index: 100px;
}
.main{
    position: absolute;
    top: 44px;
    bottom: 48px;
    overflow-y: scroll;
    width:100%;
    max-width: 640px;
    scrollbar-width: none;   
}
.main::-webkit-scrollbar{
    display: none;
}

</style>